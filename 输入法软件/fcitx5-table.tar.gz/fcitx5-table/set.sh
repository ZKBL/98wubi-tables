#!/bin/bash
sudo cp -rf ./fcitx5/table/*.dict /usr/share/libime
sudo cp -rf ./fcitx5/table/*.conf /usr/share/fcitx5/inputmethod
sudo cp -rf ./fcitx5/bd/punc.mb.zh_CN /usr/share/fcitx5/punctuation
sudo chmod -R 777 /usr/share/fcitx5
sudo chmod -R 777 /usr/share/libime/*
sudo chmod -R 777 /usr/share/fcitx5/inputmethod/*

if [ ! -d ~/.config/fcitx5/table ]; then
  mkdir ~/.config/fcitx5/table
fi
sudo rm -rf ~/.config/fcitx5/table/*
sudo cp -rf ./fcitx5/table/*.conf ~/.config/fcitx5/table
sudo chmod -R 777 ~/.config/fcitx5/table
echo "已成功为『fcitx』添加『98五笔』，请重启或注销系统一次后，在对应的设置面板中添加！"
